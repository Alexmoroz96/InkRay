var right = document.getElementsByClassName('right')[0];
var left = document.getElementsByClassName('left')[0];
var tc = document.getElementsByClassName('team-container')[0];
var next = -300;
var count = 0;
right.onclick = function () {
if (count == 4) {
    		count = 0;
    		next = 0;
    		tc.style.marginLeft = next + 'px';
    	}
else {
    		tc.style.marginLeft = next + 'px';
   			 next = next - 300;
   			 count++;
    	}
}
right.onmouseover = function () {
	right.style.color = 'blue';
}
right.onmouseout = function () {
	right.style.color = '#871527';
}
left.onmouseover = function () {
	left.style.color = 'blue';
}
left.onmouseout = function () {
	left.style.color = '#871527';
}
left.onclick = function () {
		if (count == 0)  {
			count = 4;
			next = -1200;
			tc.style.marginLeft = next + 'px';

		}
			else {
				next = next + 300;
   			 count--;
	tc.style.marginLeft = next + 'px';
			}
}
var slider = document.getElementsByClassName('slider');
var home = document.getElementsByClassName('home')[0]

var counter = 0;

function a () {
	if (counter == slider.length - 1) {
		slider[0].className = 'slider slider-active';
		slider[2].className = 'slider';
		counter = 0;
	}
	else {
		slider[counter + 1].className = 'slider slider-active';
		slider[counter].className = 'slider';
		counter++;
	}
	if (counter == 0) {
		home.style.background = 'url("Img/sloy1.png")';
		home.style.backgroundSize = 'cover';
	}
	if (counter == 1) {
		home.style.background = 'url("Img/sloy2.png")';
		home.style.backgroundSize = 'cover';
	}
	if (counter == 2) {
		home.style.background = 'url("Img/sloy3.png")';
		home.style.backgroundSize = 'cover';
    }

}


setInterval(a, 4000);

slider[0].onclick = function a () {
	slider[0].className = 'slider slider-active';
	slider[1].className = 'slider';
	slider[2].className = 'slider';
	counter = 0;
	home.style.background = 'url("Img/sloy1.png")';
	home.style.backgroundSize = 'cover';
}
slider[1].onclick = function b () {
	slider[0].className = 'slider';
	slider[1].className = 'slider slider-active';
	slider[2].className = 'slider';
	home.style.background = 'url("Img/sloy2.png")';
	home.style.backgroundSize = 'cover';
	counter = 1;

}
slider[2].onclick = function c () {
	slider[0].className = 'slider';
	slider[1].className = 'slider';
	slider[2].className = 'slider slider-active';
	home.style.background = 'url("Img/sloy3.png")';
	home.style.backgroundSize = 'cover';
	counter = 2;

}